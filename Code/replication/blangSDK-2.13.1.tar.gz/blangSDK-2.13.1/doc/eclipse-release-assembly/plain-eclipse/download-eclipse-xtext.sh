#!/bin/bash

wget http://downloads.yoctoproject.org/eclipse-full/technology/epp/downloads/release/2019-03/R/eclipse-dsl-2019-03-R-macosx-cocoa-x86_64.dmg

echo "Unpack and put Eclipse.app in here"