package blang.runtime.internals.doc;

public class Categories 
{
  public static final String 
    reference = "Reference",
    tools = "Tools";

  private Categories() {}
}
