package blang.types;

import xlinear.Matrix;

public interface Simplex extends Matrix 
{

}
