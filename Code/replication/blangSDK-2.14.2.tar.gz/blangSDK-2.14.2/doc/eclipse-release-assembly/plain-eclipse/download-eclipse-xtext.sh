#!/bin/bash

wget https://ftp.osuosl.org/pub/eclipse/technology/epp/downloads/release/2020-12/R/eclipse-dsl-2020-12-R-macosx-cocoa-x86_64.dmg

echo "Unpack and put Eclipse.app in here"