package blang.mcmc.internals.bps;

import java.util.List;

import org.apache.commons.math3.analysis.differentiation.FiniteDifferencesDifferentiator;

import blang.core.LogScaleFactor;
//import ca.ubc.bps.energies.Energy;
//import ca.ubc.bps.state.MutableDouble;

public class Likelihood2EnergyAdaptor //implements Energy
{
//  private final LogScaleFactor logScaleFactor;
//  
//  private final List<MutableDouble> variables;
//  
//  @Override
//  public double[] gradient(double[] point) 
//  {
//    use http://commons.apache.org/proper/commons-math/javadocs/api-3.4/org/apache/commons/math3/analysis/differentiation/FiniteDifferencesDifferentiator.html
//    dont forget to negate
//    
//    FiniteDifferencesDifferentiator xxx
//    
//    return null;
//  }
//  
//  @Override
//  public double valueAt(double[] point) 
//  {
//    dont forget to negate
//    return 0;
//  }
}
