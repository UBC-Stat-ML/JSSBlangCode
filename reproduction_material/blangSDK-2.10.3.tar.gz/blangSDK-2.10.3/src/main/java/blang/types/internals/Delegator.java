package blang.types.internals;

public interface Delegator<T> 
{
  T getDelegate();
}
