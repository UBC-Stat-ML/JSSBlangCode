package blang.mcmc.internals.bps;

import blang.core.WritableRealVar;
//import ca.ubc.bps.state.MutableDouble;

public class RealVar2MutableDouble //implements MutableDouble
{
//  private final WritableRealVar realVar;
//  
//  public RealVar2MutableDouble(WritableRealVar realVar) 
//  {
//    this.realVar = realVar;
//  }
//
//  @Override
//  public void set(double value) 
//  {
//    realVar.set(value);
//  }
//
//  @Override
//  public double get() 
//  {
//    return realVar.doubleValue();
//  }
//
//  @Override
//  public String toString() {
//    return realVar.toString();
//  }
}
